# Landing Page Project

This is my first project, and I hope to be successful in using the tools that I learned to implement what is required of me in this project.

I have added the sections via JavaScript.

I created a function to create a link for each section.

Modified the active class properties for both section and link.

I made a button to create additional partitions.

I made an icon to go to the top of the page.

I made the icon appear after scaling to 800 pixels.

I made the link header disappear after 8 seconds and reappear with just a scroll.